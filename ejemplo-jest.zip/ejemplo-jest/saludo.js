// saludo.js
function saludo(nombre) {
  return `Hola, ${nombre}`;
}
module.exports = saludo;
