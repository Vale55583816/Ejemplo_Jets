//saludo.test.js
const saludo = require('./saludo');

test('saludo devuelve el nombre correcto', () => {
  expect(saludo('Usuario')).toBe('Hola, Usuario');
});
